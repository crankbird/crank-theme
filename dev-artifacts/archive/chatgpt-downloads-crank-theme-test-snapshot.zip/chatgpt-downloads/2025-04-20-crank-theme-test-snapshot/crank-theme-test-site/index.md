---
layout: default
title: Home
---

# Welcome to the Crank Theme Test Site

This is a live test harness for validating the theme's layout and post rendering.

{% include post-list.html %}
