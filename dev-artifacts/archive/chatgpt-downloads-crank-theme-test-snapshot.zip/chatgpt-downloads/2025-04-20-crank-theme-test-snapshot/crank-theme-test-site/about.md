---
layout: default
title: About
---

# About This Blog

This is a boilerplate "About" page for a Jekyll blog powered by the `crank-theme`.

The theme was developed by [Crankbird](https://github.com/crankbird) to explore clean, semantic, and accessible web design using Jekyll with minimal dependencies.

You can read more about the design principles behind this theme on the [Design Philosophy](/design) page.
