---
layout: post
title: Sample Post
author: Test Author
tags: [example, markdown]
---

This is a test post for the crank-theme snapshot. It demonstrates basic Markdown rendering and post layout.

![Image One](/assets/images/sample-1.png)

Some bullet points:

- A
- B
- C

![Image Two](/assets/images/sample-2.png)
