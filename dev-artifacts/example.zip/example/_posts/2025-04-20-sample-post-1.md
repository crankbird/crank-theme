---
layout: post
title: "Sample Post 1"
author: "Author 1"
tags: ["example", "post1"]
---

![Card Image](/assets/images/sample-post-1-1.png)

This is the first paragraph of **Sample Post 1**, demonstrating some basic Markdown formatting, including `inline code`, *italics*, and **bold**.

## Subheading Example

Here's a secondary section with a bullet list:

- Point A
- Point B
- Point C

![Second Image](/assets/images/sample-post-1-2.png)

You can also add a [link](https://example.com) or horizontal rule below:

---

That’s it for this post!
