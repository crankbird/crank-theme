---
layout: post
title: "Sample Post 2"
author: "Author 2"
tags: ["example", "post2"]
---

![Card Image](/assets/images/sample-post-2-1.png)

This is the first paragraph of **Sample Post 2**, demonstrating some basic Markdown formatting, including `inline code`, *italics*, and **bold**.

## Subheading Example

Here's a secondary section with a bullet list:

- Point A
- Point B
- Point C

![Second Image](/assets/images/sample-post-2-2.png)

You can also add a [link](https://example.com) or horizontal rule below:

---

That’s it for this post!
