---
layout: default
title: Home
---

# Welcome to Crank Theme

This is a minimal working Jekyll site powered by `crank-theme`.

- Edit this file to customize your homepage.
- Change styles in `_sass/main.scss`
- Layout is defined in `_layouts/default.html`


Here's a preview of recent posts:

{% include post-list.html %}