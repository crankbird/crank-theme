---
layout: default
title: Home
---

# Welcome to the SCSS Test

If this background is pink and text is white, it works.
