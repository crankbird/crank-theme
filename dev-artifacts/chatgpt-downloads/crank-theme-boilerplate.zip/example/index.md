---
layout: default
title: Home
---

# Welcome to Crank Theme

This is a minimal test site using the `crank-theme`.
